import React from 'react';

const Contact = () => (
  <div className="contact-container">
    <h1>Contact Us</h1>
    <p><strong>Mithulal Bishwakarma</strong><br />CEO & Founder<br />mi@infinitypax.london<br />0044.7729.669.690</p>
    <p><strong>Mo Kityamuwesi</strong><br />Creative & Co-Founder<br />mo@infinitypax.london<br />0044.7919.145.866</p>
  </div>
);

export default Contact;