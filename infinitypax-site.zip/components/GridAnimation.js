import React from 'react';

const GridAnimation = () => {
  return (
    <div className="grid-animation">
      <p>I P A U S U C U</p>
      {/* Add animation logic here */}
    </div>
  );
};

export default GridAnimation;