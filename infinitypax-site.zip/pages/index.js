import React from 'react';
import GridAnimation from '../components/GridAnimation';

export default function Home() {
  return (
    <main>
      <GridAnimation />
    </main>
  );
}